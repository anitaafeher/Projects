--Precleansing of database
DROP TABLE IF EXISTS 
    students,
    courses,
    course_types,
    attended_courses,
    projects,
    project_list,
    teams,
    reviews,
    assessments,
    background_materials,
    pr_bgr_connect,
    tasks;

-- Tabel Creation commands

-- TABLE: students

CREATE TABLE students 
(
    id SERIAL PRIMARY KEY,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    nickname VARCHAR (50),
    birth_date DATE,
    email VARCHAR(255),
    address VARCHAR (255)
);

-- TABLE: course_types
CREATE TABLE course_types
(
    id SERIAL PRIMARY KEY,
    name VARCHAR(100),
    course_fee INT,
    training_duration INTERVAL,
    class_start_time TIME,
    class_end_time TIME,
    class_per_week SMALLINT CHECK (class_per_week BETWEEN 1 AND 7)
);

-- TABLE: courses

CREATE TABLE courses
(
    id SERIAL PRIMARY KEY,
    course_type_id INT,
    start_date DATE,
    FOREIGN KEY (course_type_id) REFERENCES course_types(id)
);



--TABLE: attended_courses

CREATE TABLE attended_courses
(
    student_id INT,
    course_id INT,
    date_of_joining DATE,
    FOREIGN KEY(student_id) REFERENCES students(id),
    FOREIGN KEY(course_id) REFERENCES courses (id)
);

--TABLE: projects

CREATE TABLE projects
(
    id SERIAL PRIMARY KEY,
    title VARCHAR (100),
    category VARCHAR (50),
    difficulty DECIMAL(3,2) CHECK (difficulty BETWEEN 1.00 AND 5.00)
);

--TABLE: project_list

CREATE TABLE project_list(
    id VARCHAR(20) GENERATED ALWAYS AS (course_id || '.' || project_id) STORED PRIMARY KEY,
    course_id INT,
    project_id INT,
    FOREIGN KEY(course_id) REFERENCES courses(id),
    FOREIGN KEY(project_id) REFERENCES projects(id)
);
--TABLE: teams

CREATE TABLE teams
(
    id SERIAL PRIMARY KEY,
    project_list_id VARCHAR(20),
    student_id INT,
    team_name VARCHAR(50),
    FOREIGN KEY(project_list_id) REFERENCES project_list(id),
    FOREIGN KEY(student_id) REFERENCES students(id),
    CONSTRAINT teams_unique_rule UNIQUE(project_list_id,student_id)
);

--TABLE: reviews

CREATE TABLE reviews
(
    id SERIAL PRIMARY KEY,
    student_id INT,
    review_date DATE,
    reviewer_score SMALLINT NOT NULL CHECK(reviewer_score BETWEEN 1 AND 5), --Megkötés: érték 1 és 5 között
    reviewer_thoughts VARCHAR(255),
    FOREIGN KEY(student_id) REFERENCES students(id)
);

--TABLE: assessments 

CREATE TABLE assessments
(
    id SERIAL PRIMARY KEY,
    project_list_id VARCHAR(20),
    student_id INT,
    submission_date DATE,
    time INTERVAL,
    review_id INT CHECK(review_id <> student_id),
    FOREIGN KEY(review_id) REFERENCES reviews(id),
    FOREIGN KEY(project_list_id) REFERENCES project_list(id),
    FOREIGN KEY(student_id) REFERENCES students(id),
    CONSTRAINT assesments_unique_rule UNIQUE(project_list_id,student_id)    
);

--TABLE: background_materials

CREATE TABLE background_materials
(
    id SERIAL PRIMARY KEY,
    name VARCHAR (255),
    link VARCHAR (255)
);

--TABLE: pr_bgr_connect

CREATE TABLE pr_bgr_connect
(
    project_id INT,
    background_material_id INT,
    FOREIGN KEY(project_id) REFERENCES projects(id),
    FOREIGN KEY(background_material_id) REFERENCES background_materials(id),
    CONSTRAINT unique_project_background UNIQUE (project_id, background_material_id)
);

--TABLE: tasks

CREATE TABLE tasks
(
    id SERIAL PRIMARY KEY,
    project_id INT,
    name VARCHAR (50),
    FOREIGN KEY(project_id) REFERENCES projects(id)
);

--ALTER TABLE courses DROP Column description;
--ALTER TABLE courses ADD training_duration INTERVAL;
--Alter TAble courses ADD class_start_time TIME;
--Alter TAble courses ADD class_end_time TIME;