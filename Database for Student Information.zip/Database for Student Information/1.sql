CREATE DATABASE Students_Codecool;

-- Connection Details:
-- Name: Students_Codecool
-- username: posgres
-- password: posgres
-- database: students_codecool