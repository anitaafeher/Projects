-- 1. Exercises and other projects are listed by courses

SELECT 
    projects.id,
    projects.title,
    ARRAY_AGG(course_types.name) AS course_names
FROM project_list
JOIN courses ON project_list.course_id = courses.id
JOIN course_types ON courses.course_type_id = course_types.id
JOIN projects ON project_list.project_id = projects.id
GROUP BY projects.title, projects.id
ORDER BY projects.title; 

-- 2. Individual projects with all related elements are listed
SELECT 
    *
FROM projects
FULL JOIN pr_bgr_connect ON
    projects.id=pr_bgr_connect.project_id
FULL JOIN background_materials ON
    pr_bgr_connect.background_material_id=background_materials.id;

SELECT 
    attended_courses.course_id, 
    students.first_name || ' ' || students.last_name AS student_name,
    students.id
FROM attended_courses
RIGHT JOIN students ON
    students.id=attended_courses.student_id;

SELECT 
    students.first_name, 
    students.last_name, 
    attended_courses.course_id
FROM students
JOIN attended_courses ON 
    students.id = attended_courses.student_id
ORDER BY 
    attended_courses.course_id, 
    students.last_name, 
    students.first_name;

SELECT 
    students.first_name || ' ' || students.last_name AS student_name,
    attended_courses.student_id,
    attended_courses.course_id,
    course_types.name
FROM attended_courses
JOIN students ON
    students.id=attended_courses.student_id
JOIN courses ON
    attended_courses.course_id=courses.id
JOIN course_types ON
    courses.course_type_id=course_types.id
ORDER BY
    "student_name";

SELECT 
    assessments.project_list_id,
    students.first_name,
    students.last_name,
    reviewer_score,
    review_date,
    reviewer_thoughts
FROM students
JOIN assessments ON 
    students.id = assessments.student_id
JOIN reviews ON 
    assessments.review_id = reviews.id;

--Aggregated result of the students' performance
SELECT 
    students.first_name || students.last_name AS student_name,
    AVG(reviews.reviewer_score) AS average_score,
    CASE 
        WHEN AVG(reviews.reviewer_score) > 3.2 THEN 'advanced'
        ELSE 'considered advanced'
    END AS performance_rating
FROM students
JOIN assessments ON students.id=assessments.student_id
JOIN reviews ON assessments.review_id=reviews.id
GROUP BY student_name
ORDER BY average_score;

--6. List of the 3 best performing students based on their cumulative (not average) scores
SELECT
    assessments.student_id,
    first_name || ' ' || last_name AS student_name,
    SUM(reviewer_score) AS scores
FROM assessments
JOIN reviews ON assessments.review_id=reviews.id
JOIN students ON assessments.student_id=students.id
GROUP BY assessments.student_id, student_name
ORDER BY SUM(reviewer_score) DESC
LIMIT 3;
