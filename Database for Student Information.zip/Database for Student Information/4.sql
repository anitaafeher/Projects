-- Reviews to make sense (a review can only be made after assesment is proceeded):
UPDATE reviews
SET review_date = submission_date + INTERVAL '1 DAY' * FLOOR(RANDOM() * 10)  -- Set a new review date between 1 and 10 days after submission_date
FROM assessments
WHERE reviews.id = assessments.review_id AND reviews.review_date < assessments.submission_date;


--updating and removing duplicate links
--duplicate link count, all id, and connections.
SELECT
    background_materials.link,
    COUNT(background_materials.id),
    ARRAY_AGG(background_materials.id) AS bgm_ids,
    ARRAY_AGG(pr_bgr_connect.project_id) AS connected_project_ids
FROM background_materials
JOIN pr_bgr_connect ON background_materials.id=pr_bgr_connect.background_material_id
GROUP BY link
ORDER BY COUNT(background_materials.id) DESC;

-- There are 12 dupliated links. We got all the id we need (some even more then 2).
-- Updating the table based on Query result
-- UPDATE: replace in relations all bgm_id with the lowest bgm_id
-- DELETE: keepeing only the lowest id number, deleting others

--bgm_id=104

SELECT*
FROM pr_bgr_connect WHERE background_material_id=104;

UPDATE pr_bgr_connect
SET background_material_id=104
WHERE background_material_id=124; 

UPDATE pr_bgr_connect
SET background_material_id=104
WHERE background_material_id=125;

UPDATE pr_bgr_connect 
SET background_material_id=104 
WHERE background_material_id=132;

DELETE FROM background_materials 
WHERE id = 124;
DELETE FROM background_materials 
WHERE id = 125;
DELETE FROM background_materials 
WHERE id = 132;

-- bgm_id=83
UPDATE pr_bgr_connect
SET background_material_id=83
WHERE background_material_id=126; 

UPDATE pr_bgr_connect
SET background_material_id=83
WHERE background_material_id=133;

DELETE FROM background_materials 
WHERE id = 126;
DELETE FROM background_materials 
WHERE id = 133;

--bgm_id=55
UPDATE pr_bgr_connect
SET background_material_id=55
WHERE background_material_id=65; 

UPDATE pr_bgr_connect
SET background_material_id=55
WHERE background_material_id=69;

DELETE FROM background_materials 
WHERE id = 65;
DELETE FROM background_materials 
WHERE id = 69;

--bgm_id=54
UPDATE pr_bgr_connect
SET background_material_id=54
WHERE background_material_id=64; 

UPDATE pr_bgr_connect
SET background_material_id=54
WHERE background_material_id=68;

DELETE FROM background_materials 
WHERE id = 64;
DELETE FROM background_materials 
WHERE id = 68;
--bgm_id=52
UPDATE pr_bgr_connect
SET background_material_id=52
WHERE background_material_id=118;

DELETE FROM background_materials 
WHERE id = 118;
--bgm_id=23
UPDATE pr_bgr_connect
SET background_material_id=23
WHERE background_material_id=114;

DELETE FROM background_materials 
WHERE id = 114;
--bgm_id=105
UPDATE pr_bgr_connect
SET background_material_id=105
WHERE background_material_id=130;

DELETE FROM background_materials 
WHERE id = 130;
--bgm_id=53
UPDATE pr_bgr_connect
SET background_material_id=53
WHERE background_material_id=119;

DELETE FROM background_materials 
WHERE id = 119;
--bgm_id=160
UPDATE pr_bgr_connect
SET background_material_id=160
WHERE background_material_id=167;

DELETE FROM background_materials 
WHERE id = 167;
--bgm_id=84
UPDATE pr_bgr_connect
SET background_material_id=84
WHERE background_material_id=127;

DELETE FROM background_materials 
WHERE id = 127;
--bgm_id=112
UPDATE pr_bgr_connect
SET background_material_id=112
WHERE background_material_id=129;

DELETE FROM background_materials 
WHERE id = 129;