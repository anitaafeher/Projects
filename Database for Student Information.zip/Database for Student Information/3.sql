-- Insert Into Students Table Commands.

-- Data2409 course students
INSERT INTO students (first_name, last_name, nickname, birth_date, email, address)
VALUES
    ('Anita','Fehér','Anita','1994-01-02', 'anitaafeher@gmail.com','1122 Budapest, Szamos utca 5.'), --** Pleas, fill in the missing information :D
    ('Boldizsár','Ekker','Boldizsár',NULL,NULL,NULL),
    ('Balázs','Bock','Balázs',NULL,NULL,NULL),
    ('Csaba','Bőde','Csaba',NULL,NULL,NULL),
    ('Dániel','Seres','Dani',NULL,NULL,NULL),
    ('László','Lengyel','Laci',NULL,NULL,NULL),
    ('Meir','Bern','Meir',NULL,NULL,NULL),
    ('Márton','Onódy','Marci','1997-09-18','onodymarton@gmial.com','1171 Budapest, Strázsahegy utca 21.');


-- Randomly generated data using chatgpt.

INSERT INTO students (first_name, last_name, nickname, birth_date, email, address)
VALUES ('Bence', 'Nagy', 'Ben', '1998-05-12', 'bence.nagy@gmail.com', 'Budapest, Andrássy út 60.');

INSERT INTO students (first_name, last_name, nickname, birth_date, email, address)
VALUES ('László', 'Kovács', 'Laci', '1997-07-23', 'laszlo.kovacs@freemail.hu', 'Debrecen, Piac utca 5.');

INSERT INTO students (first_name, last_name, nickname, birth_date, email, address)
VALUES ('Réka', 'Szabó', 'Reki', '2000-03-15', 'reka.szabo@citromail.hu', 'Szeged, Kossuth Lajos sugárút 17.');

INSERT INTO students (first_name, last_name, nickname, birth_date, email, address)
VALUES ('Péter', 'Tóth', 'Peti', '1999-08-20', 'peter.toth@gmail.com', 'Győr, Baross Gábor utca 22.');

INSERT INTO students (first_name, last_name, nickname, birth_date, email, address)
VALUES ('Zsófia', 'Varga', 'Zsófi', '2001-12-02', 'zsofia.varga@freemail.hu', 'Miskolc, Széchenyi István utca 9.');

INSERT INTO students (first_name, last_name, nickname, birth_date, email, address)
VALUES ('Balázs', 'Kiss', 'Bali', '1996-11-28', 'balazs.kiss@citromail.hu', 'Pécs, Rákóczi út 47.');

INSERT INTO students (first_name, last_name, nickname, birth_date, email, address)
VALUES ('Eszter', 'Horváth', 'Eszti', '1998-04-07', 'eszter.horvath@gmail.com', 'Székesfehérvár, Mátyás Király körút 12.');

INSERT INTO students (first_name, last_name, nickname, birth_date, email, address)
VALUES ('Gábor', 'Molnár', 'Gabi', '1997-09-15', 'gabor.molnar@freemail.hu', 'Nyíregyháza, Vasvári Pál utca 8.');

INSERT INTO students (first_name, last_name, nickname, birth_date, email, address)
VALUES ('Anna', 'Balogh', 'Anci', '1999-06-11', 'anna.balogh@citromail.hu', 'Kecskemét, Nagykőrösi utca 10.');

INSERT INTO students (first_name, last_name, nickname, birth_date, email, address)
VALUES ('Levente', 'Lukács', 'Levi', '1998-01-03', 'levente.lukacs@gmail.com', 'Szeged, Tisza Lajos körút 3.');

INSERT INTO students (first_name, last_name, nickname, birth_date, email, address)
VALUES ('Krisztina', 'Kis', 'Kriszti', '2000-07-22', 'krisztina.kis@freemail.hu', 'Debrecen, Csapó utca 19.');

INSERT INTO students (first_name, last_name, nickname, birth_date, email, address)
VALUES ('Bálint', 'Farkas', 'Bali', '1996-02-14', 'balint.farkas@citromail.hu', 'Pécs, Szabadság utca 7.');

INSERT INTO students (first_name, last_name, nickname, birth_date, email, address)
VALUES ('Katalin', 'Németh', 'Kati', '1997-12-06', 'katalin.nemeth@gmail.com', 'Budapest, Rákóczi út 14.');

INSERT INTO students (first_name, last_name, nickname, birth_date, email, address)
VALUES ('Zoltán', 'Papp', 'Zoli', '2001-10-18', 'zoltan.papp@freemail.hu', 'Székesfehérvár, Budai út 5.');

INSERT INTO students (first_name, last_name, nickname, birth_date, email, address)
VALUES ('Ágnes', 'Juhász', 'Ági', '1999-08-09', 'agnes.juhasz@citromail.hu', 'Debrecen, Kálvin tér 12.');

INSERT INTO students (first_name, last_name, nickname, birth_date, email, address)
VALUES ('Tamás', 'Szalai', 'Tomi', '2000-11-30', 'tamas.szalai@gmail.com', 'Győr, Szent István út 15.');

INSERT INTO students (first_name, last_name, nickname, birth_date, email, address)
VALUES ('Viktória', 'Simon', 'Viki', '1998-05-18', 'viktoria.simon@freemail.hu', 'Pécs, Kertváros utca 9.');

INSERT INTO students (first_name, last_name, nickname, birth_date, email, address)
VALUES ('Norbert', 'Bodnár', 'Nori', '1996-03-25', 'norbert.bodnar@citromail.hu', 'Budapest, Budaörsi út 22.');

INSERT INTO students (first_name, last_name, nickname, birth_date, email, address)
VALUES ('Nikolett', 'Mészáros', 'Niki', '1997-10-05', 'nikolett.meszaros@gmail.com', 'Szeged, Szegfű utca 8.');

INSERT INTO students (first_name, last_name, nickname, birth_date, email, address)
VALUES ('Attila', 'Kovács', 'Ati', '2001-02-16', 'attila.kovacs@freemail.hu', 'Miskolc, Kinizsi Pál utca 6.');

INSERT INTO students (first_name, last_name, nickname, birth_date, email, address)
VALUES ('Melinda', 'Tóth', 'Meli', '2002-04-03', 'melinda.toth@gmail.com', 'Kecskemét, Fő utca 11.');

INSERT INTO students (first_name, last_name, nickname, birth_date, email, address)
VALUES ('Dávid', 'Váradi', 'Dávid', '1998-12-19', 'david.varadi@citromail.hu', 'Budapest, Üllői út 52.');

INSERT INTO students (first_name, last_name, nickname, birth_date, email, address)
VALUES ('Fanni', 'Fehér', 'Fanni', '1996-09-24', 'fanni.feher@freemail.hu', 'Szeged, Nagykörút 3.');

INSERT INTO students (first_name, last_name, nickname, birth_date, email, address)
VALUES ('Zsolt', 'Takács', 'Zsolti', '1997-11-13', 'zsolt.takacs@gmail.com', 'Nyíregyháza, Búza tér 20.');

INSERT INTO students (first_name, last_name, nickname, birth_date, email, address)
VALUES ('Lilla', 'Németh', 'Lili', '1999-07-04', 'lilla.nemeth@citromail.hu', 'Pécs, Hunyadi János utca 18.');

INSERT INTO students (first_name, last_name, nickname, birth_date, email, address)
VALUES ('István', 'Balázs', 'Pisti', '1998-05-27', 'istvan.balazs@freemail.hu', 'Debrecen, Kossuth utca 9.');

INSERT INTO students (first_name, last_name, nickname, birth_date, email, address)
VALUES ('Erika', 'Fekete', 'Eri', '2001-01-01', 'erika.fekete@gmail.com', 'Budapest, Szentendrei út 22.');

INSERT INTO students (first_name, last_name, nickname, birth_date, email, address)
VALUES ('Dániel', 'Szilágyi', 'Dani', '1997-03-12', 'daniel.szilagyi@citromail.hu', 'Székesfehérvár, Petőfi Sándor utca 10.');

INSERT INTO students (first_name, last_name, nickname, birth_date, email, address)
VALUES ('Áron', 'Boros', 'Áron', '2000-10-31', 'aron.boros@freemail.hu', 'Pécs, Zsolnay Vilmos út 8.');

INSERT INTO students (first_name, last_name, nickname, birth_date, email, address)
VALUES ('Kinga', 'Varga', 'Kingi', '1996-04-18', 'kinga.varga@gmail.com', 'Kecskemét, Rákóczi út 1.');

INSERT INTO students (first_name, last_name, nickname, birth_date, email, address)
VALUES ('János', 'Barta', 'Jani', '1999-06-05', 'janos.barta@citromail.hu', 'Miskolc, Fő utca 7.');

INSERT INTO students (first_name, last_name, nickname, birth_date, email, address)
VALUES ('Hanna', 'Oláh', 'Hanna', '2001-11-11', 'hanna.olah@freemail.hu', 'Nyíregyháza, Szent István tér 3.');

INSERT INTO students (first_name, last_name, nickname, birth_date, email, address)
VALUES ('Zsombor', 'Major', 'Zsom', '1997-09-03', 'zsombor.major@gmail.com', 'Győr, Vásárhelyi Pál utca 5.');

INSERT INTO students (first_name, last_name, nickname, birth_date, email, address)
VALUES ('Vivien', 'Sipos', 'Vivi', '1996-08-29', 'vivien.sipos@citromail.hu', 'Budapest, Váci út 12.');

INSERT INTO students (first_name, last_name, nickname, birth_date, email, address)
VALUES ('Gergő', 'Kis', 'Geri', '1998-07-14', 'gergo.kis@gmail.com', 'Székesfehérvár, Várkörút 6.');

INSERT INTO students (first_name, last_name, nickname, birth_date, email, address)
VALUES ('Noémi', 'Tóth', 'Noémi', '2000-01-20', 'noemi.toth@freemail.hu', 'Pécs, Árkád utca 15.');

INSERT INTO students (first_name, last_name, nickname, birth_date, email, address)
VALUES ('Ferenc', 'Sipos', 'Feri', '1999-05-07', 'ferenc.sipos@citromail.hu', 'Debrecen, Veres Péter utca 21.');

INSERT INTO students (first_name, last_name, nickname, birth_date, email, address)
VALUES ('Enikő', 'Fazekas', 'Eni', '2002-03-29', 'eniko.fazekas@gmail.com', 'Győr, Móricz Zsigmond utca 9.');

INSERT INTO students (first_name, last_name, nickname, birth_date, email, address)
VALUES ('Boglárka', 'Molnár', 'Bogi', '1998-02-11', 'boglarka.molnar@citromail.hu', 'Miskolc, Batthyány utca 4.');

INSERT INTO students (first_name, last_name, nickname, birth_date, email, address)
VALUES ('Máté', 'Kovács', 'Mati', '1997-01-18', 'mate.kovacs@gmail.com', 'Nyíregyháza, Sóstói út 7.');

INSERT INTO students (first_name, last_name, nickname, birth_date, email, address)
VALUES ('Patrícia', 'Székely', 'Pati', '2000-06-26', 'patricia.szekely@freemail.hu', 'Szeged, Feketesas utca 11.');

INSERT INTO students (first_name, last_name, nickname, birth_date, email, address)
VALUES ('Gábor', 'Török', 'Gabi', '1998-12-22', 'gabor.torok@gmail.com', 'Kecskemét, Bocskai utca 2.');

INSERT INTO students (first_name, last_name, nickname, birth_date, email, address)
VALUES ('Dorina', 'Barna', 'Dóri', '1999-10-12', 'dorina.barna@citromail.hu', 'Budapest, Hűvösvölgyi út 35.');

INSERT INTO students (first_name, last_name, nickname, birth_date, email, address)
VALUES ('Ádám', 'Nagy', 'Ádi', '1996-09-30', 'adam.nagy@gmail.com', 'Debrecen, Derék utca 17.');

SELECT *From students;
--Inserting data into course_type and courses table.
-- Created by data gathering on journey and Codecool web: 
--https://codecool.com/hu/kepzesek/

INSERT INTO course_types (name,
    course_fee,
    training_duration,
    class_start_time,
    class_end_time,
    class_per_week)
VALUES
    ('Data Analyst',950000,'3 months','16:00','18:00',5),
    ('Full Stack fejlesztő',2560000,'10 months','09:00','15:00',5),
    ('Frontend fejlesztő nappali',990000,'4 months','09:00','13:00',5),
    ('Frontend fejlesztő esti',990000,'4 months','09:00','13:00',3),
    ('Szoftvertesztelő',799000,'3 months','09:00','13:00',5),
    ('Rendszerüzemeltető',950000,'4 months','09:00','13:00',5);


INSERT INTO courses (
    course_type_id,
    start_date
)
VALUES
    (1,'2024-09-02'),--1
    (2,'2024-09-16'),--2
    (3,'2024-09-16'),--3
    (4,'2024-09-16'),--4
    (5,'2024-09-02'),--5
    (1,'2024-03-02'),--6
    (1,'2024-06-05'),--7
    (1,'2024-01-04');--8


-- Inserting data into attended_courses table

-- Data2409 student connection data

INSERT INTO attended_courses(
    course_id,
    student_id
)
VALUES
    (1,1),
    (1,2),
    (1,3),
    (1,4),
    (1,5),
    (1,6),
    (1,7),
    (1,8);
INSERT INTO attended_courses(
    course_id,
    student_id
)
VALUES
    (6, 10),
    (6, 12),
    (6, 14),
    (6, 18),
    (6, 9),
    (6, 11),
    (6, 15),
    (6, 17),
    (6, 13),
    (6, 16),
    (7, 22),
    (7, 19),
    (7, 27),
    (7, 20),
    (7, 24),
    (7, 21),
    (7, 25),
    (7, 26),
    (7, 28),
    (7, 23),
    (8, 30),
    (8, 42),
    (8, 39),
    (8, 32),
    (8, 34),
    (8, 29),
    (8, 41), 
    (2, 41), 
    (8, 36),
    (8, 35),
    (8, 40),
    (8, 38),
    (8, 48),
    (8, 51),
    (8, 45),
    (8, 46),
    (8, 47),
    (8, 52),
    (8, 50),
    (8, 49),
    (8, 31);


-- Insert into projects table:

INSERT INTO projects(
    title,
    category,
    difficulty
)
VALUES
    ('Onboarding Data Analyst','Exercise',2.1),--1
    ('Introduction to Excel for Data Analysis','Tutorial',NULL),--2
    ('Speedy Excel','Exercise',1.9),--3
    ('The cleanliness of sport','Exerciese',2.9),--4
    ('Visualize your data in Excel','Exercise',3.2),--5
    ('Git Started','Exercise',3.5),--6
    ('Show Me Your Hobby','Exercise',2.0),--7
    ('Grocery sales','Exercise',3.1),--8
    ('Restaurants of New York','Exercise',3.2),--9
    ('Linear regression','Exercise',3.0),--10
    ('Personal Budget','Exercise',3.6),--11 TEAM
    ('Gitting around','Execise',3.6),--12
    ('Introduction to SQL','Tutorial',NULL),--13
    ('Setup PostgreSQL','Exercise',3.6),--14
    ('Project Codewars - 7kyu in SQL','Exercise',2.9),--15
    ('TodoDb.sql','Exercise',3.1 ),--16
    ('Northwind Traders','Exercies',3.8),--17
    ('Students of Codecool','Exercise',4.3),--18 TEAM
    ('Introduction to Python','Exercise',2.5),--19
    ('Hello, Console!','Exercise',2.7),--20
    ('Project Codewars - Loops and conditionals','Exercise',2.8),--21
    ('Project Codewars - Data structures','Exercise',3.2),--22
    ('Projects Codewars - Data operations','Exercise',3.8),--23
    ('Project rewrite','Exercise',3.5),--24
    ('World of Data','Exercise',3.0),--25
    ('Setup Python for Data','Exercise',2.5),--26
    ('Growth Mindset','Exercise',2.2),--27
    ('Hangman','Exercise',4.0),--28 TEAM
    ('Game inventory','Exercise',4.5),--29
    ('String theory','Exercise',3.1),--30
    ('Ideabank','Exercise',3.8),--31
    ('Mastermind','Guided project',4.1),--32
    ('Filetree','Exercise',3.6),--33
    ('Collect personal data (Streamlit)','Exercise',4.5),--34 TEAM
    ('True Detective','Exercise',3.5),--35
    ('Working with Time Series','Exercise',3.6),--36
    ('Working with Spreadsheets','Exercise',3.5),--37
    ('Sail Into the Wind','Exercise',3.6),--38 TEAM
    ('Spanish league','Exercise',3.8),--39
    ('Working with data types','Exercise',2.3),--40
    ('Joining DataFrames','Exercise',2.0),--41
    ('Iris','Exercise',3.5),--42
    ('Order by Height','Exercise',3.0),--43
    ('General Social Survey','Exercise',2.0),--44
    ('Linear regression in Python','Exercise',3.0),--45
    ('Superstore','Exercise',4.5);--46 TEAM

    --**UPDATED more Projects from Data analyst
    --** other projects not being part of data course

-- Insert Into project_list

-- Data0924 relevant data insertion

INSERT INTO project_list (
    course_id,
    project_id
)
VALUES
    (1, 1),
    (1, 2),
    (1, 3),
    (1, 4),
    (1, 5),
    (1, 6),
    (1, 7),
    (1, 8),
    (1, 9),
    (1, 10),
    (1, 11),
    (1, 12),
    (1, 13),
    (1, 14),
    (1, 15),
    (1, 16),
    (1, 17),
    (1, 18),
    (1, 19),
    (1, 20),
    (1, 21),
    (1, 22),
    (1, 23),
    (1, 24),
    (1, 25),
    (1, 26),
    (1, 27),
    (1, 28),
    (1, 29),
    (1, 30),
    (1, 31),
    (1, 32),
    (1, 33),
    (1, 34),
    (1, 35),
    (1, 36),
    (1, 37),
    (1, 38),
    (1, 39),
    (1, 40),
    (1, 41),
    (1, 42),
    (1, 43),
    (1, 44),
    (1, 45),
    (1, 46);

INSERT INTO project_list (
    course_id,
    project_id
)
VALUES
    (6, 1),
    (6, 2),
    (6, 3),
    (6, 4),
    (6, 5),
    (6, 6),
    (6, 7),
    (6, 8),
    (6, 9),
    (6, 10),
    (6, 11),
    (6, 12),
    (6, 13),
    (6, 14),
    (6, 15),
    (6, 16),
    (6, 17),
    (6, 18),
    (6, 19),
    (6, 20),
    (6, 21),
    (6, 22),
    (6, 23),
    (6, 24),
    (6, 25),
    (6, 26),
    (6, 27),
    (6, 28),
    (6, 29),
    (6, 30),
    (6, 31),
    (6, 32),
    (6, 33),
    (6, 34),
    (6, 35),
    (6, 36),
    (6, 37),
    (6, 38),
    (6, 39),
    (6, 40),
    (6, 41),
    (6, 42),
    (6, 43),
    (6, 44),
    (6, 45),
    (6, 46);
INSERT INTO project_list (
    course_id,
    project_id
)
VALUES
    (7, 1),
    (7, 2),
    (7, 3),
    (7, 4),
    (7, 5),
    (7, 6),
    (7, 7),
    (7, 8),
    (7, 9),
    (7, 10),
    (7, 11),
    (7, 12),
    (7, 13),
    (7, 14),
    (7, 15),
    (7, 16),
    (7, 17),
    (7, 18),
    (7, 19),
    (7, 20),
    (7, 21),
    (7, 22),
    (7, 23),
    (7, 24),
    (7, 25),
    (7, 26),
    (7, 27),
    (7, 28),
    (7, 29),
    (7, 30),
    (7, 31),
    (7, 32),
    (7, 33),
    (7, 34),
    (7, 35),
    (7, 36),
    (7, 37),
    (7, 38),
    (7, 39),
    (7, 40),
    (7, 41),
    (7, 42),
    (7, 43),
    (7, 44),
    (7, 45),
    (7, 46);
    INSERT INTO project_list (
    course_id,
    project_id
)
VALUES
    (8, 1),
    (8, 2),
    (8, 3),
    (8, 4),
    (8, 5),
    (8, 6),
    (8, 7),
    (8, 8),
    (8, 9),
    (8, 10),
    (8, 11),
    (8, 12),
    (8, 13),
    (8, 14),
    (8, 15),
    (8, 16),
    (8, 17),
    (8, 18),
    (8, 19),
    (8, 20),
    (8, 21),
    (8, 22),
    (8, 23),
    (8, 24),
    (8, 25),
    (8, 26),
    (8, 27),
    (8, 28),
    (8, 29),
    (8, 30),
    (8, 31),
    (8, 32),
    (8, 33),
    (8, 34),
    (8, 35),
    (8, 36),
    (8, 37),
    (8, 38),
    (8, 39),
    (8, 40),
    (8, 41),
    (8, 42),
    (8, 43),
    (8, 44),
    (8, 45),
    (8, 46);

    INSERT INTO project_list (
    course_id,
    project_id
)
VALUES
    (2,45);

SELECT * From project_list;

    -- Other relations to be coded when projects table is more complete
    --** other course connection imitating data (ChatGPT or random number generatior)

--Insert Into teams
INSERT INTO teams(
    project_list_id,
    student_id,
    team_name
)
VALUES
    ('1.11', 1, 'team1'),
    ('1.11', 2, 'team1'),
    ('1.11', 3, 'team2'),
    ('1.11', 4, 'team2'),
    ('1.11', 5, 'team3'),
    ('1.11', 6, 'team3'),
    ('1.11', 7, 'team4'),
    ('1.11', 8, 'team4'),
    ('1.18', 2, 'team1'),
    ('1.18', 3, 'team1'),
    ('1.18', 4, 'team2'),
    ('1.18', 5, 'team2'),
    ('1.18', 6, 'team3'),
    ('1.18', 7, 'team3'),
    ('1.18', 1, 'team4'),
    ('1.18', 8, 'team4'),
    ('1.28', 1, NULL),
    ('1.28', 2, NULL),
    ('1.28', 3, NULL),
    ('1.28', 4, NULL),
    ('1.28', 5, NULL),
    ('1.28', 6, NULL),
    ('1.28', 7, NULL),
    ('1.28', 8, NULL),
    ('1.34', 1, NULL),
    ('1.34', 2, NULL),
    ('1.34', 3, NULL),
    ('1.34', 4, NULL),
    ('1.34', 5, NULL),
    ('1.34', 6, NULL),
    ('1.34', 7, NULL),
    ('1.34', 8, NULL),
    ('1.38', 1, NULL),
    ('1.38', 2, NULL),
    ('1.38', 3, NULL),
    ('1.38', 4, NULL),
    ('1.38', 5, NULL),
    ('1.38', 6, NULL),
    ('1.38', 7, NULL),
    ('1.38', 8, NULL),
    ('1.46', 1, NULL),
    ('1.46', 2, NULL),
    ('1.46', 3, NULL),
    ('1.46', 4, NULL),
    ('1.46', 5, NULL),
    ('1.46', 6, NULL),
    ('1.46', 7, NULL),
    ('1.46', 8, NULL);


--INSERT INTO reviews
INSERT INTO reviews(
    student_id,
    review_date,
    reviewer_score,
    reviewer_thoughts
)
VALUES
    (15, '2024.08.30', 1, 'Pathetic'), --1
    (8, '2024.09.22', 4, NULL), --2
    (30, '2024.05.16', 3, NULL), --3
    (10, '2024.06.30', 2, NULL), --4
    (16, '2024.06.09', 3, NULL), --5
    (11, '2024.08.29', 4, NULL), --6
    (4, '2024.09.12', 2, NULL), --7
    (19, '2024.02.22', 5, NULL), --8
    (14, '2024.03.06', 5, NULL), --9
    (45, '2024.05.28', 2, NULL), --10
    (37, '2024.08.14', 4, NULL), --11
    (41, '2024.04.20', 1, NULL), --12
    (14, '2024.06.13', 2, NULL), --13
    (41, '2024.07.21', 4, NULL), --14
    (3, '2024.09.26', 4, NULL), --15
    (17, '2024.06.12', 4, NULL), --16
    (47, '2024.07.04', 3, NULL), --17
    (30, '2024.07.25', 1, NULL), --18
    (28, '2024.06.09', 3, NULL), --19
    (31, '2024.04.06', 1, NULL), --20
    (50, '2024.09.13', 5, 'WOW! <3'), --21
    (36, '2024.07.28', 5, 'GOOD JOB!!'), --22
    (41, '2024.04.16', 1, NULL), --23
    (27, '2024.01.25', 4, NULL), --24
    (24, '2024.08.02', 1, NULL), --25
    (37, '2024.09.14', 1, NULL), --26
    (29, '2024.07.21', 4, NULL), --27
    (6, '2024.09.15', 3, NULL), --28
    (33, '2024.01.25', 5, NULL), --29
    (42, '2024.04.05', 4, NULL), --30
    (28, '2024.03.06', 5, NULL), --31
    (38, '2024.02.08', 4, NULL), --32
    (4, '2024.03.14', 5, NULL), --33
    (45, '2024.03.25', 1, NULL), --34
    (30, '2024.08.04', 2, NULL), --35
    (42, '2024.08.31', 1, NULL), --36
    (9, '2024.08.26', 1, NULL), --37
    (34, '2024.05.26', 4, NULL), --38
    (9, '2024.02.02', 1, NULL), --39
    (41, '2024.03.05', 3, NULL), --40
    (27, '2024.04.04', 2, NULL), --41
    (6, '2024.09.15', 4, NULL), --42
    (46, '2024.08.12', 4, NULL), --43
    (2, '2024.01.18', 5, 'Outstanding work!'), --44
    (15, '2024.04.07', 4, NULL), --45
    (16, '2024.03.05', 5, NULL), --46
    (17, '2024.08.31', 4, NULL), --47
    (39, '2024.07.29', 5, NULL), --48
    (21, '2024.04.19', 3, NULL), --49
    (25, '2024.01.03', 4, NULL), --50
    (14, '2024.09.10', 3, NULL), --51
    (11, '2024.06.18', 2, NULL); --52



--Insert Into assessments

INSERT INTO assessments(
    project_list_id,
    student_id,
    submission_date,
    time,
    review_id
)    
VALUES
    (7.40, 21, '2024-07-09','1 hour', 17),
    (6.30, 13, '2024-03-08','30 minutes', 42),
    
    -- Randomized time between '10 minutes' and '10 hours' and updated project_list_id based on submission_date:
    ('7.6', 48, '2024-07-17','4 hours 20 minutes', 45),
    ('1.20', 1, '2024-09-10','2 hours 35 minutes', 44),
    ('8.2', 35, '2024-08-23','6 hours 45 minutes', 26),
    ('7.41', 9, '2024-07-22','3 hours 15 minutes', 29),
    ('6.7', 15, '2024-05-17','5 hours 36 minutes', 24),
    ('7.19', 48, '2024-07-23','6 hours 10 minutes', 31),
    ('8.15', 28, '2024-08-22','1 hour 37 minutes', 34),
    ('7.21', 36, '2024-08-04','7 hours 50 minutes', 8),
    ('1.11', 1, '2024-09-05','45 minutes', 7),
    ('6.2', 42, '2024-08-05','3 hours 25 minutes', 41),
    ('1.11', 2, '2024-09-05','52 minutes', 7),
    ('7.4', 11, '2024-07-22','2 hours 59 minutes', 27),
    ('8.26', 12, '2024-01-21','1 hour 4 minutes', 48),
    ('1.6', 7, '2024-09-10','3 hours 11 minutes', 2),
    ('8.20', 23, '2024-02-26','6 hours 59 minutes', 12),
    ('6.40', 12, '2024-03-20','2 hours 43 minutes', 16),
    ('8.31', 19, '2024-02-03','3 hours 37 minutes', 17),
    ('1.28', 3, '2024-09-25','3 hours 19 minutes', 47),
    ('1.19', 4, '2024-09-13','4 hours 23 minutes', 1),
    ('7.31', 9, '2024-07-06','3 hours 45 minutes', 43),
    ('7.42', 42, '2024-05-29','3 hours 20 minutes', 16),
    ('8.24', 39, '2024-09-19','8 hours 10 minutes', 23),
    ('6.24', 47, '2024-03-29','13 minutes', 5),
    ('7.22', 39, '2024-05-28','16 hours 48 minutes', 50),
    ('7.15', 32, '2024-09-20','19 hours 53 minutes', 48),
    ('6.15', 27, '2024-02-03','9 hours 13 minutes', 32),
    ('8.27', 42, '2024-01-06','3 hours 31 minutes', 45),
    ('7.5', 50, '2024-08-01','15 hours 57 minutes', 13),
    ('6.31', 39, '2024-07-07','23 hours 13 minutes', 41),
    ('8.30', 12, '2024-01-31','18 hours 14 minutes', 32),
    ('8.13', 41, '2024-01-28','4 hours 7 minutes', 17),
    ('6.23', 17, '2024-03-11','34 minutes', 32),
    ('7.15', 43, '2024-02-20','1 hour 37 minutes', 38),
    ('1.38', 7, '2024-09-08','1 hour 4 minutes', 42),
    ('6.36', 51, '2024-05-19','11 hours 59 minutes', 27),
    ('7.45', 26, '2024-07-23','15 hours 53 minutes', 22),
    ('8.43', 23, '2024-01-11','19 hours 50 minutes', 39),
    ('1.20', 7, '2024-09-18','20 hours 29 minutes', 33),
    ('6.24', 45, '2024-03-28','32 minutes', 25),
    ('1.6', 4, '2024-09-12','3 hours 16 minutes', 41),
    ('1.10', 2, '2024-09-24','4 hours 56 minutes', 8),
    ('6.4', 42, '2024-06-20','23 hours 36 minutes', 19),
    ('1.9', 2, '2024-09-20','3 hours 27 minutes', 40),
    ('7.15', 14, '2024-04-20','4 hours 34 minutes', 48),
    ('1.15', 3, '2024-09-10','3 hours 3 minutes', 15),
    ('1.8',7, '2024-09-11','19 hours 50 minutes', 28);



--Insert Into background_materials

INSERT INTO background_materials(
    name,
    link)

VALUES
    --Onboarding Data Analyst - id 1
('Codecooler Onboarding', 'https://journey.study/v2/learn/materials/pages/codecool-general/data-analyst-onboarding.md'),
('Video about the Google Suite', 'https://journey.study/v2/learn/materials/pages/tools/google-suite.md'),
('Codecool Manifesto', 'https://journey.study/v2/learn/materials/pages/codecool-general/codecool-manifesto.md'),
('Codecool Methodology', 'https://journey.study/v2/learn/materials/pages/codecool-general/codecool-methodology.md'),
('Minimum requirements for Codecoolers', 'https://journey.study/v2/learn/materials/pages/codecool-general/minimum-requirements-for-codecoolers.md'),
('Codecool Code of Ethics', 'https://static.journey.study/media/general/codecool_code_of_conduct_2019.pdf?_gl=1*hle373*_gcl_au*MjY1NTU0MjkwLjE3MjUyNzc0Njc.'),
--Speedy Excel - id 3
(NULL, 'https://www.simplilearn.com/tutorials/excel-tutorial/excel-shortcuts#workbook_shortcut_keys'),
--The cleanliness of sport - id 4
('How to remove duplicates', 'https://www.excel-easy.com/examples/remove-duplicates.html'),
('Convert text to columns wizard', 'https://support.microsoft.com/en-us/office/split-text-into-different-columns-with-the-convert-text-to-columns-wizard-30b14928-5550-41f5-97ca-7a3e9c363ed7'),
('UNIQUE formula', 'https://support.microsoft.com/en-us/office/unique-function-c5ab87fd-30a3-4ce9-9d1a-40204fb85e1e'),
('Change the case of text', 'https://support.microsoft.com/en-au/office/change-the-case-of-text-01481046-0fa7-4f3b-a693-496795a7a44d'),
('Using Flash fill in Excel', 'https://support.microsoft.com/en-us/office/using-flash-fill-in-excel-3f9bcf1e-db93-4890-94a0-1578341f73f7'),
('Go to special', 'https://corporatefinanceinstitute.com/resources/excel/go-to-special-excel/'),
--Visualize your data in Excel - id 5
('Create a chart from start to finish', 'https://support.microsoft.com/en-us/office/create-a-chart-from-start-to-finish-0baf399e-dd61-4e18-8a73-b3fd5d5680c2'),
('Histogram', 'https://www.excel-easy.com/examples/histogram.html'),
--Git Started - id 6
('Step-by-step setup guide', 'https://journey.study/v2/learn/materials/tutorials/git-ssh-setup.md'),
('Git without password', 'https://journey.study/v2/learn/materials/pages/git/git-passwordless.md'),
('Git basics', 'https://journey.study/v2/learn/materials/pages/git/git-basics.md'),
('Git tutorial video', 'https://www.youtube.com/watch?v=HVsySz-h9r4'),
('Learning Git concepts', 'https://dev.to/unseenwizzard/learn-git-concepts-not-commands-4gjc'),
('A simple guide about Git', 'http://rogerdudler.github.io/git-guide/'),
('Git home page', 'https://git-scm.com/'),
('About nice commit messages', 'https://chris.beams.io/posts/git-commit/'),
('A comprehensive and free Git book', 'https://git-scm.com/book/en/v2'),
('.gitignore generator', 'http://gitignore.io/'),
('Lorem Ipsum generator', 'https://loremipsum.io/'),
('Gits original introduction by Linus Torvalds', 'https://github.com/git/git/blob/e83c5163316f89bfbde7d9ab23ca2e25604af290/README'),
('Linus Torvalds talk about why was Git created and how it works', 'https://www.youtube.com/watch?v=4XpnKHJAok8'),
--Show Me Your Hobby -- id 7
('Creating a new presentation', 'https://support.google.com/docs/answer/2763168?co=GENIE.Platform%3DDesktop&hl=en'),
('Change theme, background, layout', 'https://support.google.com/docs/answer/1705254'),
('Inserting and arranging objects', 'https://support.google.com/docs/answer/1696521'),
('Adding, deleting and organizing slides', 'https://support.google.com/docs/answer/1694830'),
('Adding animations', 'https://support.google.com/docs/answer/1689475'),
('Using themes', 'https://support.google.com/docs/answer/1689475'),
('Some extra themes for Google Slides', 'https://slidesgo.com/'),
--Grocery sales --id 8
('', 'https://community.tableau.com/s/question/0D54T00000CWeX8SAL/sample-superstore-sales-excelxls'),
--Restaurants of New York - id 9
('Top 25 Formulas in Excel You Should Know', 'https://www.simplilearn.com/tutorials/excel-tutorial/excel-formulas'),
('Overview of formulas in Excel', 'https://support.microsoft.com/en-us/office/overview-of-formulas-in-excel-ecfdc708-9162-49e8-b993-c311f47ca173'),
--Linear regression id 10
('', 'https://www.ablebits.com/office-addins-blog/linear-regression-analysis-excel/'),
('', 'https://www.youtube.com/watch?v=L_a8Z0BVjyM'),
--Personal budget - id 11
('Create and share a Dashboard', 'https://support.microsoft.com/en-us/office/create-and-share-a-dashboard-with-excel-and-microsoft-groups-ad92a34d-38d0-4fdd-b8b1-58379aae746e'),
('Available chart types in Office', 'https://support.microsoft.com/en-us/office/available-chart-types-in-office-a6187218-807e-4103-9e0a-27cdb19afb90'),
--Gitting around - id 12
('Moving around branches', 'https://www.atlassian.com/git/tutorials/using-branches/git-checkout'),
('Branches in a nutshell', 'https://git-scm.com/book/en/v2/Git-Branching-Branches-in-a-Nutshell'),
('Bash commands and arguments', 'https://mywiki.wooledge.org/BashGuide/CommandsAndArguments'),
('Bash pattern matching', 'https://mywiki.wooledge.org/BashGuide/Patterns'), 
('Mastering git', 'https://journey.study/v2/learn/materials/pages/git/mastering-git.md'),
--Introduction to SQL - id 13
('About databases', 'https://journey.code.cool/v2/learn/materials/competencies/database-basics/about-databases.md'),
('Relational databases', 'https://journey.code.cool/v2/learn/materials/competencies/database-basics/relational-databases.md'),
('About SQL', 'https://journey.code.cool/v2/learn/materials/competencies/sql-basics/about-sql.md'),
('Introduction to JOINs', 'https://journey.code.cool/v2/learn/materials/competencies/sql-basics/sql-joins.md'),
--Setup PostgreSQL -id 14
('Installing and setting up PostgreSQL', 'https://journey.study/v2/learn/materials/pages/tools/installing-postgresql.md'),
('Installing psycopg2', 'https://journey.study/v2/learn/materials/pages/tools/installing-psycopg2.md'),
('Short guide about psql', 'http://postgresguide.com/utilities/psql.html'),
('PostgreSQL documentation page about psql', 'https://www.postgresql.org/docs/current/app-psql.html'),
('Installing PostgreSQL extension in Visual Studio Code', 'https://marketplace.visualstudio.com/items?itemName=ckolkman.vscode-postgres'),
('Setting up a database connection in PyCharm', 'https://journey.study/v2/learn/materials/pages/tools/pycharm-database.md'),
--TodoDB.sql -id 16
('Introduction to SQL', 'https://journey.study/v2/learn/materials/tutorials/introduction-to-sql.md'),
('General SQL tutorial', 'https://w3schools.com/sql/default.asp'),
('Interactive SQL tutorial', 'https://www.w3schools.com/sql/exercise.asp'),
('Primary key - postgres', 'https://www.postgresqltutorial.com/postgresql-primary-key/'),
('Foreign key - postgres', 'https://www.postgresqltutorial.com/postgresql-foreign-key/'),
('UPDATE examples', 'https://www.postgresql.org/docs/10/sql-update.html'),
('Short guide about psql', 'http://postgresguide.com/utilities/psql.html'),
('PostgreSQL documentation about psql', 'https://www.postgresql.org/docs/current/app-psql.html'),
--Northwind Traders - id 17
('Working with more complex data', 'https://journey.study/v2/learn/materials/pages/sql/sql-working-with-data.md'),
('Northwind database', 'https://www.geeksengine.com/article/northwind.html'),
('Short guide about psql', 'http://postgresguide.com/utilities/psql.html'),
('PostgreSQL documentation page about psql', 'https://www.postgresql.org/docs/current/app-psql.html'),
--Students of Codecool - id 18
('ER diagram maker', 'https://www.drawio.com/'),
('SQL Tutorial', 'https://www.w3schools.com/sql/'),
('ER diagram backgrounds', 'https://www.lucidchart.com/pages/er-diagrams'),
--Introduction to Python - id 19
('Educative.io Learn Python3 from scratch', 'https://www.educative.io/courses/learn-python-3-from-scratch'),
('Python 3 Tutorial', 'https://docs.python.org/3/tutorial/'),
('collection of tutorials', 'https://realpython.com/'),
('pythonbasics.org', 'https://pythonbasics.org/'),
('tutorial video', 'https://www.youtube.com/watch?v=N4mEzFDjqtA'),
--Hello, Console! - id 20
('Command line arguments in Python', 'https://www.educative.io/edpresso/command-line-arguments-in-python'),
('Slicing sequences', 'https://note.nkmk.me/en/python-slice-usage/'),
('Joining list elements', 'https://www.geeksforgeeks.org/join-function-python/'),
--Project Codewars - Data structures - id 22
('Python Dictionaries', 'https://www.w3schools.com/python/python_dictionaries.asp'),
--Project rewrite - id 24
('Numbers', 'https://journey.study/v2/learn/materials/competencies/python-basics/python-numbers.md'),
('Control structures', 'https://journey.study/v2/learn/materials/competencies/python-basics/python-control-structures.md'),
('Functions', 'https://journey.study/v2/learn/materials/competencies/python-basics/python-functions.md'),
--World of Data id 25
('Data Science vs. Data Analytics vs. Machine Learning: Expert Talk', 'https://www.simplilearn.com/data-science-vs-data-analytics-vs-machine-learning-article'),
('Data Analytics vs. Data Science: A Breakdown', 'https://www.northeastern.edu/graduate/blog/data-analytics-vs-data-science/'),
('Data Analytics DA', 'https://www.techtarget.com/searchdatamanagement/definition/data-analytics'),
('Building a strong data analytics platform architecture', 'https://www.techtarget.com/searchdatamanagement/feature/Building-a-strong-data-analytics-platform-architecture?_gl=1*1tk3575*_ga*MTYwNzMwOTU2Ni4xNjY5MDk1MDM1*_ga_TQKE4GS5P9*MTY2OTA5NTAzNC4xLjEuMTY2OTA5NTE2Mi4wLjAuMA..'),
--Setup Python for Data - id 26
('Installing Python', 'https://journey.study/v2/learn/materials/competencies/python-environment/python-install.md'),
('Installing Python package manager', 'https://journey.study/v2/learn/materials/competencies/python-environment/python-install-pip.md'),
('Setting up VS Code', 'https://journey.study/v2/learn/materials/pages/tools/vs-code.md'),
('Setting up and using rope', 'https://journey.study/v2/learn/materials/pages/tools/use-refactor-rename.md'),
('Installing IPython', 'https://journey.study/v2/learn/materials/pages/tools/installing-ipython.md'),
('Installing Anaconda', 'https://www.anaconda.com/'),
('Using Jupyter Notebooks', 'https://journey.study/v2/learn/materials/pages/tools/using-notebooks.md'),
('Using IPython', 'https://journey.study/v2/learn/materials/competencies/python-environment/python-interactive-shell.md'),
('About IDEs', 'https://journey.study/v2/learn/materials/pages/tools/about-ides.md'),
--Growth Mindset id 27
('Carol Dweck advice video', 'https://www.youtube.com/watch?v=SuHtP6fjEdE'),
('Growth mindset summary video', 'https://www.youtube.com/watch?v=75GFzikmRY0'),
('Carol Dweck - Mindset: The New Psychology of Success', 'https://books.google.hu/books/about/Mindset.html?id=bOGHDQAAQBAJ&source=kp_book_description&redir_esc=y'),
('Growth Mindset presentation', 'https://docs.google.com/presentation/d/1fX2D4_20UXMbMmjKecOjU6eRlims5XANN9MwHLL5Eq4/edit?usp=sharing'),
('Mountain bike video', 'https://www.youtube.com/watch?v=K_7k3fnxPq0'),
('Neuroplasticity video', 'https://www.youtube.com/watch?v=ELpfYCZa87g'),
--Hangman - id 28
('Strings', 'https://journey.study/v2/learn/materials/competencies/python-basics/python-strings.md'),
('User input', 'https://journey.study/v2/learn/materials/competencies/python-basics/python-io.md'),
('File handling', 'https://journey.study/v2/learn/materials/pages/notebooks/file-handling.html'),
('Sets', 'https://journey.study/v2/learn/materials/competencies/python-data-structures/python-sets.md'),
--Game inventory - id 29
('Working with Dictionaries, and more Collection types', 'https://journey.study/v2/learn/materials/pages/python/working-with-dictionaries-and-more-collection-types'),
('Working with Strings', 'https://journey.study/v2/learn/materials/pages/python/working-with-strings-string-functions-and-manipulators'),
('Working with Functions and their arguments, input parameters or default parameters', 'https://journey.study/v2/learn/materials/pages/python/working-with-functions-and-their-arguments-input-parameters-or-default-parameters'),
('Sorting', 'https://journey.study/v2/learn/materials/pages/python/sorting'),
('Error handling in Python', 'https://python-textbok.readthedocs.io/en/stable/Errors_and_Exceptions.html'),
('Commit messages tutorial', 'https://www.youtube.com/watch?v=9Siot_y9wY8'),
('Deep-dive into git commit messages', 'https://chris.beams.io/posts/git-commit/'),
('Built-in Exceptions in Python', 'https://docs.python.org/3/library/exceptions.html#bltin-exceptions'),
('Modifying objects in-place', 'https://journey.study/v2/learn/materials/pages/python/modifying-objects'),
('Understanding Variable scope, lifetime, modifying values and type conversions', 'https://journey.study/v2/learn/materials/pages/python/variable-scopes-and-conversions'),
('Installing and setting up PostgreSQL', 'https://journey.study/v2/learn/materials/pages/tools/installing-postgresql.md'),
('Installing psycopg2', 'https://journey.study/v2/learn/materials/pages/tools/installing-psycopg2.md'),
('Best practices for Python/Psycopg/Postgres', 'https://journey.study/v2/learn/materials/pages/python/tips-python-psycopg-postgres'),
('Date/Time handling in psycopg2', 'https://www.psycopg.org/docs/usage.html?highlight=gunpoint#date-time-objects-adaptation'),
('PostgreSQL documentation page on Queries', 'https://www.postgresql.org/docs/current/queries.html'),
('PostgreSQL documentation page Data Manipulation', 'https://www.postgresql.org/docs/current/dml.html'),
--String theory - id 30
('Strings', 'https://journey.study/v2/learn/materials/competencies/python-basics/python-strings.md'),
--Ideabank - id 31
('Strings', 'https://journey.study/v2/learn/materials/competencies/python-basics/python-strings.md'),
('Control structures', 'https://journey.study/v2/learn/materials/competencies/python-basics/python-control-structures.md'),
('Functions', 'https://journey.study/v2/learn/materials/competencies/python-basics/python-functions.md'),
('Tutorial about command line arguments in Python', 'https://www.pythonforbeginners.com/system/python-sys-argv'),
('Error handling in Python', 'https://python-textbok.readthedocs.io/en/stable/Errors_and_Exceptions.html'),
--Mastermind - id 32
('Python IO', 'https://journey.study/v2/learn/materials/competencies/python-basics/python-io.md'),
('Python lists', 'https://journey.study/v2/learn/materials/competencies/python-basics/python-lists.md'),
('Python strings', 'https://journey.study/v2/learn/materials/competencies/python-basics/python-strings.md'),
('Python control structures', 'https://journey.study/v2/learn/materials/competencies/python-basics/python-control-structures.md'),
('A step-by-step solution guide', 'https://journey.study/v2/learn/materials/pages/guides/mastermind--python.md'),
('Mastermind on Wikipedia', 'https://en.wikipedia.org/wiki/Mastermind_(board_game)'),
--Filetree - id 33
('Whats going on under the hood', 'https://journey.study/v2/learn/materials/pages/python/whats-going-on-under-the-hood.md'),
('Debugging in Visual Studio Code', 'https://www.youtube.com/watch?v=w8QHoVam1-I'),
('Debugging in Visual Studio Code', 'https://code.visualstudio.com/docs/editor/debugging'),
('About debugging', 'https://python-textbok.readthedocs.io/en/stable/Errors_and_Exceptions.html#debugging-programs'),
('The concept of recursion', 'https://www.youtube.com/watch?v=vPEJSJMg4jY'),
('Thinking recursively in Python', 'https://realpython.com/python-thinking-recursively/'),
--Collect personal data (Streamlit) - id 34
('Streamlit documentations', 'https://docs.streamlit.io/develop/tutorials/databases/private-gsheet'),
('psycopg', 'https://www.psycopg.org/'),
('Data-Access Layer', 'https://www.geeksforgeeks.org/data-access-layer/'),
('Tkinter Data Entry Form tutorial for beginners', 'https://www.youtube.com/watch?v=vusUfPBsggw&t=2456s'),
('Create a GUI Using Tkinter and Python', 'https://www.pythonguis.com/tutorials/create-gui-tkinter/'),
('Open a new Window with a button in Python-Tkinter', 'https://www.geeksforgeeks.org/open-a-new-window-with-a-button-in-python-tkinter/'),
('Python tkinter input validation', 'https://www.plus2net.com/python/tkinter-validation.php'),
--True Detective - id 35
('Logical operators', 'https://journey.study/v2/learn/materials/pages/notebooks/logical-operators.html'),
('About pytest', 'https://docs.pytest.org/en/latest/'),
--Working with Time Series - id 36
(NULL, 'https://jakevdp.github.io/PythonDataScienceHandbook/03.11-working-with-time-series.html'),
--Working with Spreadsheets - id 37
(NULL, 'https://www.dataquest.io/blog/excel-and-pandas/'),
--Sail Into the Wind - id 38
('Desccriptive statistics', 'https://medium.com/analytics-vidhya/python-pandas-descriptive-statistics-7346b42f9774'),
('Pandas.describe', 'https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.describe.html'),
('Pandas.loc', 'https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.loc.html'),
('Pandas.groupby', 'https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.groupby.html'),
('Introduction to Pandas', 'https://journey.study/v2/learn/courses/11152/modules/32713/units/2/materials/54453'),
('Reading & Displaying Data', 'https://journey.study/v2/learn/courses/11152/modules/32713/units/2/materials/54257'),
('Data Manipulation with Pandas', 'https://journey.study/v2/learn/courses/11152/modules/32713/units/2/materials/54454'),
--Spanish league - id 39
('Handling Missing Data', 'https://jakevdp.github.io/PythonDataScienceHandbook/03.04-missing-values.html'),
('Interpolation', 'https://www.numpyninja.com/post/interpolation-using-pandas'),
--Working with data types - id 40
('numpy.where', 'https://numpy.org/doc/stable/reference/generated/numpy.where.html'),
('pandas.DataFrame.info', 'https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.info.html'),
('pandas.DataFrame.astype', 'https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.astype.html'),
('pandas.DataFrame.apply', 'https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.apply.html#pandas-dataframe-apply'),
('Python data types', 'https://www.w3schools.com/python/python_datatypes.asp'),
--Joining DataFrames - id 41
(NULL, 'https://jakevdp.github.io/PythonDataScienceHandbook/03.04-missing-values.html'),
--Iris - id 42
('First steps for visualization', 'https://towardsdatascience.com/introduction-to-data-visualization-in-python-89a54c97fbed'),
('The Iris Dataset', 'https://towardsdatascience.com/classification-basics-walk-through-with-the-iris-data-set-d46b0331bf82'),
('Plotting with categorical data', 'https://seaborn.pydata.org/tutorial/categorical.html'),
('Overplotting', 'https://www.data-to-viz.com/caveat/overplotting.html'),
('Boxplot, Quartiles, Normal distribution', 'https://towardsdatascience.com/understanding-boxplots-5e2df7bcbd51'),
('Boxplot, Quartiles, Normal distribution', 'https://seaborn.pydata.org/tutorial/distributions.html'),
('Quartiles', 'https://www.mathsisfun.com/data/quartiles.html'),
('Quartiles', 'https://towardsdatascience.com/what-are-quartiles-c3e117114cf1'),
('Graph Gallery', 'https://www.python-graph-gallery.com/'),
--Order by Height - id 43
('Descriptive Statistics', 'https://www.tutorialspoint.com/python_pandas/python_pandas_descriptive_statistics.htm'),
('Mode', 'https://www.mathsisfun.com/mode.html'),
('Mean and Standard Deviation', 'https://www.mathsisfun.com/data/standard-deviation.html'),
--General Social Survey - id 44
(NULL, 'https://byuidatascience.github.io/python4ds/factors.html'),
(NULL, 'https://medium.com/@DemetrioCN/8-easy-plotting-categorical-variables-with-seaborn-for-pandas-dataframe-15bcdc10e99a'),
(NULL, 'https://www.dataforeverybody.com/matplotlib-seaborn-pie-charts/'),
(NULL, 'https://pbpython.com/pandas_dtypes_cat.html'), 
--Linear regression in python - id 45
('Scikit-learn library', 'https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LinearRegression.html'),
('Multiple regression in python', 'https://www.w3schools.com/python/python_ml_multiple_regression.asp'),
--Superstore - id 46
('Millify', 'https://pypi.org/project/millify/'),
('Python human readable large numbers', 'https://itecnote.com/tecnote/python-human-readable-large-numbers/'),
('Streamlite metric', 'https://docs.streamlit.io/library/api-reference/data/st.metric'),
('Striamlite library', 'https://docs.streamlit.io/library/get-started'),
('Streamlite chart elements', 'https://docs.streamlit.io/library/api-reference/charts'),
('Plotly indicator', 'https://plotly.com/python/indicator/'),
('Plotly vs matplotlib', 'https://www.activestate.com/blog/plotting-data-in-python-matplotlib-vs-plotly/'),
('Altair documentation', 'https://altair-viz.github.io/index.html');
SELECT * FROM background_materials;



INSERT INTO pr_bgr_connect
VALUES
    (1,1),
    (1,2),
    (1,3),
    (1,4),
    (1,5),
    (1,6),
    (3,7),
    (4,8),
    (4,9),
    (4,10),
    (4,11),
    (4,12),
    (4,13),
    (5,14),
    (5,15),
    (6,16),
    (6,17),
    (6,18),
    (6,19),
    (6,20),
    (6,21),
    (6,22),
    (6,23),
    (6,24),
    (6,25),
    (6,26),
    (6,27),
    (6,28),
    (7,29),
    (7,30),
    (7,31),
    (7,32),
    (7,33),
    (7,34),
    (7,35),
    (8,36),
    (9,37),
    (9,38),
    (10,39),
    (10,40),
    (11,41),
    (11,42),
    (12,43),
    (12,44),
    (12,45),
    (12,46),
    (12,47),
    (13,48),
    (13,49),
    (13,50),
    (13,51),
    (14,52),
    (14,53),
    (14,54),
    (14,55),
    (14,56),
    (14,57),
    (16,58),
    (16,59),
    (16,60),
    (16,61),
    (16,62),
    (16,63),
    (16,64),
    (16,65),
    (17,66),
    (17,67),
    (17,68),
    (17,69),
    (18,70),
    (18,71),
    (18,72),
    (19,73),
    (19,74),
    (19,75),
    (19,76),
    (19,77),
    (20,78),
    (20,79),
    (20,80),
    (22,81),
    (24,82),
    (24,83),
    (24,84),
    (25,85),
    (25,86),
    (25,87),
    (25,88),
    (26,89),
    (26,90),
    (26,91),
    (26,92),
    (26,93),
    (26,94),
    (26,95),
    (26,96),
    (26,97),
    (27,98),
    (27,99),
    (27,100),
    (27,101),
    (27,102),
    (27,103),
    (28,104),
    (28,105),
    (28,106),
    (28,107),
    (29,108),
    (29,109),
    (29,110),
    (29,111),
    (29,112),
    (29,113),
    (29,114),
    (29,115),
    (29,116),
    (29,117),
    (29,118),
    (29,119),
    (29,120),
    (29,121),
    (29,122),
    (29,123),
    (30,124),
    (31,125),
    (31,126),
    (31,127),
    (31,128),
    (31,129),
    (32,130),
    (32,131),
    (32,132),
    (32,133),
    (32,134),
    (32,135),
    (33,136),
    (33,137),
    (33,138),
    (33,139),
    (33,140),
    (33,141),
    (34,142),
    (34,143),
    (34,144),
    (34,145),
    (34,146),
    (34,147),
    (34,148),
    (35,149),
    (35,150),
    (36,151),
    (37,152),
    (38,153),
    (38,154),
    (38,155),
    (38,156),
    (38,157),
    (38,158),
    (38,159),
    (39,160),
    (39,161),
    (40,162),
    (40,163),
    (40,164),
    (40,165),
    (40,166),
    (41,167),
    (42,168),
    (42,169),
    (42,170),
    (42,171),
    (42,172),
    (42,173),
    (42,174),
    (42,175),
    (42,176),
    (43,177),
    (43,178),
    (43,179),
    (44,180),
    (44,181),
    (44,182),
    (44,183),
    (45,184),
    (45,185),
    (46,186),
    (46,187),
    (46,188),
    (46,189),
    (46,190),
    (46,191),
    (46,192),
    (46,193);





